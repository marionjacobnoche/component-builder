﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ComponentBuilder.FactoryInterface
{
    interface IComponent
    { 
        public void Create();
        public void Read();
        public void Update();
        public void Delete();
    }
}
