﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ComponentBuilder.FactoryInterface
{
    interface IComponentFactory
    {
        public IComponent GetInstance(string alias);
    }
}
