﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Xml.Linq;

namespace ComponentBuilder.Utility
{
    public static class XmlUtility
    {
        //filePath will come normally from config file, for this purpose I will hardcode the path
        private const string filePath = @"C:\ComponentBuilder\ComponentBuilder\Data\Components.xml";


        /// <summary>Gets the Component type in XML using alias parameter.</summary>
        public static string GetComponentTypeByAlias(string alias)
        {
            XDocument xmlDoc = XDocument.Load(filePath);
            
            string startTimes = xmlDoc.Descendants("Component")
           .Where(doc => doc.Attribute("alias").Value == alias)
           .Select(x => x.Attribute("type").Value).FirstOrDefault();

            if(startTimes == null)
            {
                startTimes = "Default";
            }

            return startTimes;
        }
      
    }
}
