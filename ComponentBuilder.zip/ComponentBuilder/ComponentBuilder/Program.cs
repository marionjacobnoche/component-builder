﻿using ComponentBuilder.Factory;
using System;

namespace ComponentBuilder
{
    class Program
    {
        static void Main(string[] args)
        {
            ComponentFactory factory = new ComponentFactory();

            var address = factory.GetInstance("Address");
            address.Create();

            var account = factory.GetInstance("Account");
            account.Delete();

            var secondAccount = factory.GetInstance("Account");
            secondAccount.Update();

            /**this is for the example to show that system will 
               go to Default class if the inputtd parameter does not 
               have a valid or existing class**/
            
            var employee = factory.GetInstance("Employee");
            employee.Read();
            // on Components.xml, Employee does not have valid class
           

        }
    }
}
