﻿using ComponentBuilder.FactoryInterface;
using ComponentBuilder.Utility;
using System;
using System.Collections.Generic;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Text;

namespace ComponentBuilder.Factory
{
    class ComponentFactory : IComponentFactory
    {
        private string DefaultComponent = "ComponentBuilder.Component.Default";

        /// <summary>Get the instance of a class using Component type retrieved in XML.</summary>
        public IComponent GetInstance(string alias)
        {
            string componentType = XmlUtility.GetComponentTypeByAlias(alias);
            var objectType = Type.GetType(componentType);
            
            if (objectType == null)
            {
                objectType = Type.GetType(DefaultComponent);
            }

            var instance = Activator.CreateInstance(objectType) as IComponent;
            
            return instance;

        }

    }

}
