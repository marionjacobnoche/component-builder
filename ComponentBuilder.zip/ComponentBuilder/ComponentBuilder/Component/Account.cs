﻿using ComponentBuilder.FactoryInterface;
using System;
using System.Collections.Generic;
using System.Text;

namespace ComponentBuilder.Component
{
    class Account : IComponent
    {
        public void Create()
        {
            Console.WriteLine("This will do create for Account class");
        }

        public void Read()
        {
            Console.WriteLine("This will do read for Account class");
        }

        public void Update()
        {
            Console.WriteLine("This will do update for Account class");
        }

        public void Delete()
        {
            Console.WriteLine("This will do delete for Account class");
        }

    }
}
