﻿using ComponentBuilder.FactoryInterface;
using System;
using System.Collections.Generic;
using System.Text;

namespace ComponentBuilder.Component
{
    class USAddress : IComponent
    {
        public void Create()
        {
            Console.WriteLine("This will do create for USAddress class");
        }

        public void Read()
        {
            Console.WriteLine("This will do read for USAddress class");
        }

        public void Update()
        {
            Console.WriteLine("This will do update for USAddress class");
        }

        public void Delete()
        {
            Console.WriteLine("This will do delete for USAddress class");
        }
    }
}
